#include "SearchEngine.h"
#ifdef __cplusplus
extern "C"{
#endif
int c_repair_main(int argc, char *argv[], struct C_SearchEngine **  engine);
#ifdef __cplusplus
}
#endif
